CREATE TRIGGER houses
AFTER INSERT ON comments
FOR EACH ROW
  BEGIN
    UPDATE houses hs
      SET hs.numRatings = hs.numRatings + 1 WHERE NEW.houseID = hs.houseID LIMIT 1;
  END;
